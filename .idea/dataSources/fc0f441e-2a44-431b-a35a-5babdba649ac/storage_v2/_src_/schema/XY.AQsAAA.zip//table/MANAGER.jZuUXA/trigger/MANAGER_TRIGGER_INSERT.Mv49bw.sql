create trigger MANAGER_TRIGGER_INSERT
  before insert
  on MANAGER
  for each row
begin
  select MID_MANAGER_SEQ.nextval into :new.MID from dual;
end;
/

