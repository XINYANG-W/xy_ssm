create trigger TR_BEFORE_INSERT_PSALES
  before insert
  on PSALES
  for each row
begin
      SELECT PID_PSALES_SEQ.nextval INTO:new.PID from dual;
    end;
/

