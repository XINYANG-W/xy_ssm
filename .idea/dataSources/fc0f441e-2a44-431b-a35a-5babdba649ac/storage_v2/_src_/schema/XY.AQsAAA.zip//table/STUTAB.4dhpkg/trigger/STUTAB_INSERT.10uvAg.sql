create trigger STUTAB_INSERT
  before insert
  on STUTAB
  for each row
begin
  select SID_STUTAB_SEQ.nextval into :new.SID from dual;
end;
/

